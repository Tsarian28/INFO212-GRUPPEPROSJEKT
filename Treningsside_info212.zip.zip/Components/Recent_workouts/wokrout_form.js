import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Save, X } from "lucide-react";

export default function WorkoutForm({ workout, onSave, onCancel }) {
  const [formData, setFormData] = useState(workout || {
    name: "",
    description: "",
    exercises: [],
    estimated_duration: 60,
    is_template: true
  });

  const addExercise = () => {
    setFormData({
      ...formData,
      exercises: [...(formData.exercises || []), {
        exercise_name: "",
        sets: 3,
        reps: 10,
        rest_seconds: 60,
        notes: ""
      }]
    });
  };

  const removeExercise = (index) => {
    setFormData({
      ...formData,
      exercises: formData.exercises.filter((_, i) => i !== index)
    });
  };

  const updateExercise = (index, field, value) => {
    const newExercises = [...formData.exercises];
    newExercises[index][field] = value;
    setFormData({ ...formData, exercises: newExercises });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      alert("Please enter a workout name");
      return;
    }
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="text-white">Workout Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-slate-300">Workout Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g., Upper Body Strength"
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-slate-300">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Brief description of this workout..."
              rows={3}
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="duration" className="text-slate-300">Estimated Duration (minutes)</Label>
            <Input
              id="duration"
              type="number"
              value={formData.estimated_duration}
              onChange={(e) => setFormData({ ...formData, estimated_duration: parseInt(e.target.value) })}
              className="bg-slate-800 border-slate-700 text-white"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-white">Exercises</CardTitle>
          <Button
            type="button"
            onClick={addExercise}
            variant="outline"
            size="sm"
            className="border-slate-700 text-slate-300 hover:bg-slate-800"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Exercise
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {formData.exercises?.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <p>No exercises added yet</p>
              <p className="text-sm mt-1">Click "Add Exercise" to start building your workout</p>
            </div>
          ) : (
            formData.exercises?.map((exercise, index) => (
              <div key={index} className="p-4 bg-slate-800/30 rounded-xl space-y-3">
                <div className="flex gap-3">
                  <Input
                    value={exercise.exercise_name}
                    onChange={(e) => updateExercise(index, "exercise_name", e.target.value)}
                    placeholder="Exercise name"
                    className="flex-1 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                  />
                  <Button
                    type="button"
                    onClick={() => removeExercise(index)}
                    variant="ghost"
                    size="icon"
                    className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs text-slate-400">Sets</Label>
                    <Input
                      type="number"
                      value={exercise.sets}
                      onChange={(e) => updateExercise(index, "sets", parseInt(e.target.value))}
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-slate-400">Reps</Label>
                    <Input
                      type="number"
                      value={exercise.reps}
                      onChange={(e) => updateExercise(index, "reps", parseInt(e.target.value))}
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-slate-400">Rest (sec)</Label>
                    <Input
                      type="number"
                      value={exercise.rest_seconds}
                      onChange={(e) => updateExercise(index, "rest_seconds", parseInt(e.target.value))}
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                  </div>
                </div>

                <Input
                  value={exercise.notes || ""}
                  onChange={(e) => updateExercise(index, "notes", e.target.value)}
                  placeholder="Optional notes..."
                  className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>
            ))
          )}
        </CardContent>
      </Card>

      <div className="flex justify-end gap-3">
        <Button
          type="button"
          onClick={onCancel}
          variant="outline"
          className="border-slate-700 text-slate-300 hover:bg-slate-800"
        >
          <X className="w-4 h-4 mr-2" />
          Cancel
        </Button>
        <Button
          type="submit"
          className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
        >
          <Save className="w-4 h-4 mr-2" />
          Save Workout
        </Button>
      </div>
    </form>
  );
}