import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dumbbell, Pencil, Trash2, Clock } from "lucide-react";
import { motion } from "framer-motion";

export default function WorkoutList({ workouts, onEdit, onDelete }) {
  return (
    <div className="grid md:grid-cols-2 gap-6">
      {workouts.length === 0 ? (
        <Card className="md:col-span-2 bg-slate-900/50 border-slate-800 backdrop-blur-xl">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <Dumbbell className="w-16 h-16 text-slate-700 mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No Workouts Yet</h3>
            <p className="text-slate-400">Create your first workout template to get started</p>
          </CardContent>
        </Card>
      ) : (
        workouts.map((workout, index) => (
          <motion.div
            key={workout.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl hover:border-slate-700 transition-all group">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <CardTitle className="text-white mb-2">{workout.name}</CardTitle>
                    {workout.description && (
                      <p className="text-sm text-slate-400">{workout.description}</p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => onEdit(workout)}
                      variant="ghost"
                      size="icon"
                      className="text-slate-400 hover:text-orange-400 hover:bg-orange-500/10"
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      onClick={() => onDelete(workout.id)}
                      variant="ghost"
                      size="icon"
                      className="text-slate-400 hover:text-red-400 hover:bg-red-500/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className="border-slate-700 text-slate-300">
                    {workout.exercises?.length || 0} exercises
                  </Badge>
                  {workout.estimated_duration && (
                    <Badge variant="outline" className="border-slate-700 text-slate-300 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {workout.estimated_duration}m
                    </Badge>
                  )}
                </div>

                {workout.exercises && workout.exercises.length > 0 && (
                  <div className="space-y-2 pt-2">
                    {workout.exercises.slice(0, 3).map((exercise, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm text-slate-400">
                        <span className="w-1 h-1 bg-orange-500 rounded-full"></span>
                        <span>{exercise.exercise_name}</span>
                        {exercise.sets && exercise.reps && (
                          <span className="text-slate-500">• {exercise.sets}×{exercise.reps}</span>
                        )}
                      </div>
                    ))}
                    {workout.exercises.length > 3 && (
                      <p className="text-xs text-slate-500 pl-3">
                        +{workout.exercises.length - 3} more exercises
                      </p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        ))
      )}
    </div>
  );
}