import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const muscleColors = {
  chest: "bg-red-500/20 text-red-400 border-red-500/30",
  back: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  legs: "bg-green-500/20 text-green-400 border-green-500/30",
  shoulders: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  arms: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  core: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  full_body: "bg-pink-500/20 text-pink-400 border-pink-500/30"
};

const difficultyColors = {
  beginner: "bg-green-500/20 text-green-400 border-green-500/30",
  intermediate: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  advanced: "bg-red-500/20 text-red-400 border-red-500/30"
};

export default function ExerciseCard({ exercise }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl hover:border-slate-700 transition-all">
      <CardHeader>
        <CardTitle className="text-white text-lg">{exercise.name}</CardTitle>
        <div className="flex flex-wrap gap-2 mt-2">
          <Badge variant="outline" className={`border ${muscleColors[exercise.muscle_group]}`}>
            {exercise.muscle_group}
          </Badge>
          <Badge variant="outline" className="border-slate-700 text-slate-300">
            {exercise.equipment}
          </Badge>
          {exercise.difficulty && (
            <Badge variant="outline" className={`border ${difficultyColors[exercise.difficulty]}`}>
              {exercise.difficulty}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="space-y-3 overflow-hidden"
            >
              {exercise.instructions && (
                <div>
                  <h4 className="text-sm font-semibold text-white mb-2">Instructions</h4>
                  <p className="text-sm text-slate-400 whitespace-pre-line">{exercise.instructions}</p>
                </div>
              )}

              {exercise.tips && (
                <div>
                  <h4 className="text-sm font-semibold text-white mb-2">Form Tips</h4>
                  <p className="text-sm text-slate-400 whitespace-pre-line">{exercise.tips}</p>
                </div>
              )}

              {exercise.video_url && (
                <div>
                  <h4 className="text-sm font-semibold text-white mb-2">Video Demo</h4>
                  <a
                    href={exercise.video_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-orange-400 hover:text-orange-300 underline"
                  >
                    Watch demonstration
                  </a>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => setExpanded(!expanded)}
          className="w-full text-slate-400 hover:text-white hover:bg-slate-800"
        >
          {expanded ? (
            <>
              <ChevronUp className="w-4 h-4 mr-2" />
              Show Less
            </>
          ) : (
            <>
              <ChevronDown className="w-4 h-4 mr-2" />
              View Details
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}