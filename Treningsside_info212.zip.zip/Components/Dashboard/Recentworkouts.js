import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import { Dumbbell, Clock, Smile, Meh, Frown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

const feelingIcons = {
  great: { icon: Smile, color: "text-green-400" },
  good: { icon: Smile, color: "text-blue-400" },
  okay: { icon: Meh, color: "text-yellow-400" },
  tired: { icon: Meh, color: "text-orange-400" },
  struggled: { icon: Frown, color: "text-red-400" }
};

export default function RecentWorkouts({ logs, loading }) {
  return (
    <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Dumbbell className="w-5 h-5 text-orange-400" />
          Recent Workouts
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {loading ? (
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="p-4 bg-slate-800/30 rounded-xl">
              <Skeleton className="h-5 w-32 mb-2 bg-slate-700" />
              <Skeleton className="h-4 w-48 bg-slate-700" />
            </div>
          ))
        ) : logs.length === 0 ? (
          <div className="text-center py-12 text-slate-400">
            <Dumbbell className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No workouts logged yet</p>
            <p className="text-sm mt-1">Start your fitness journey today!</p>
          </div>
        ) : (
          logs.map((log) => {
            const FeelingIcon = log.feeling ? feelingIcons[log.feeling]?.icon : null;
            const feelingColor = log.feeling ? feelingIcons[log.feeling]?.color : "";

            return (
              <div key={log.id} className="p-4 bg-slate-800/30 rounded-xl hover:bg-slate-800/50 transition-all">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-white">{log.workout_name}</h3>
                  {FeelingIcon && <FeelingIcon className={`w-5 h-5 ${feelingColor}`} />}
                </div>
                <div className="flex flex-wrap gap-3 text-sm text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {log.duration_minutes || 0}m
                  </span>
                  <span>{format(new Date(log.date), "MMM d, yyyy")}</span>
                  <Badge variant="outline" className="border-slate-700 text-slate-300">
                    {log.exercises_completed?.length || 0} exercises
                  </Badge>
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}