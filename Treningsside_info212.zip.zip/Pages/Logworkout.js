import React, { useState, useEffect } from "react";
import { WorkoutLog, Workout, Exercise } from "@/entities/all";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Save, Timer, Smile, Meh, Frown } from "lucide-react";
import { format } from "date-fns";

export default function LogWorkout() {
  const navigate = useNavigate();
  const [workouts, setWorkouts] = useState([]);
  const [selectedWorkoutId, setSelectedWorkoutId] = useState("");
  const [workoutName, setWorkoutName] = useState("");
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [duration, setDuration] = useState(60);
  const [exercises, setExercises] = useState([]);
  const [notes, setNotes] = useState("");
  const [feeling, setFeeling] = useState("good");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadWorkouts();
    const urlParams = new URLSearchParams(window.location.search);
    const workoutId = urlParams.get("workout_id");
    if (workoutId) {
      loadWorkoutTemplate(workoutId);
    }
  }, []);

  const loadWorkouts = async () => {
    const data = await Workout.list("-created_date");
    setWorkouts(data);
  };

  const loadWorkoutTemplate = async (workoutId) => {
    const workout = await Workout.get(workoutId);
    setSelectedWorkoutId(workoutId);
    setWorkoutName(workout.name);
    setExercises(workout.exercises?.map(ex => ({
      ...ex,
      sets_completed: Array(ex.sets || 3).fill(null).map(() => ({
        reps: ex.reps || 0,
        weight: 0,
        completed: false
      }))
    })) || []);
  };

  const addExercise = () => {
    setExercises([...exercises, {
      exercise_name: "",
      sets_completed: [{ reps: 0, weight: 0, completed: false }]
    }]);
  };

  const removeExercise = (index) => {
    setExercises(exercises.filter((_, i) => i !== index));
  };

  const addSet = (exerciseIndex) => {
    const newExercises = [...exercises];
    newExercises[exerciseIndex].sets_completed.push({ reps: 0, weight: 0, completed: false });
    setExercises(newExercises);
  };

  const updateExercise = (exerciseIndex, field, value) => {
    const newExercises = [...exercises];
    newExercises[exerciseIndex][field] = value;
    setExercises(newExercises);
  };

  const updateSet = (exerciseIndex, setIndex, field, value) => {
    const newExercises = [...exercises];
    newExercises[exerciseIndex].sets_completed[setIndex][field] = value;
    setExercises(newExercises);
  };

  const handleSave = async () => {
    if (!workoutName.trim()) {
      alert("Please enter a workout name");
      return;
    }

    setSaving(true);
    try {
      await WorkoutLog.create({
        workout_id: selectedWorkoutId || null,
        workout_name: workoutName,
        date,
        duration_minutes: parseInt(duration),
        exercises_completed: exercises,
        notes,
        feeling
      });
      navigate(createPageUrl("Dashboard"));
    } catch (error) {
      alert("Error saving workout. Please try again.");
    }
    setSaving(false);
  };

  const feelingOptions = [
    { value: "great", label: "Great", icon: Smile, color: "text-green-400" },
    { value: "good", label: "Good", icon: Smile, color: "text-blue-400" },
    { value: "okay", label: "Okay", icon: Meh, color: "text-yellow-400" },
    { value: "tired", label: "Tired", icon: Meh, color: "text-orange-400" },
    { value: "struggled", label: "Struggled", icon: Frown, color: "text-red-400" }
  ];

  return (
    <div className="min-h-screen p-4 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-white">Log Workout</h1>
          <Button
            onClick={handleSave}
            disabled={saving}
            className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
          >
            <Save className="w-4 h-4 mr-2" />
            {saving ? "Saving..." : "Save Workout"}
          </Button>
        </div>

        <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
          <CardHeader>
            <CardTitle className="text-white">Workout Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="template" className="text-slate-300">Load Template (Optional)</Label>
                <Select value={selectedWorkoutId} onValueChange={loadWorkoutTemplate}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                    <SelectValue placeholder="Select a workout template" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {workouts.map((workout) => (
                      <SelectItem key={workout.id} value={workout.id} className="text-white">
                        {workout.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="workout-name" className="text-slate-300">Workout Name *</Label>
                <Input
                  id="workout-name"
                  value={workoutName}
                  onChange={(e) => setWorkoutName(e.target.value)}
                  placeholder="e.g., Upper Body Push"
                  className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="date" className="text-slate-300">Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="bg-slate-800 border-slate-700 text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="duration" className="text-slate-300 flex items-center gap-2">
                  <Timer className="w-4 h-4" />
                  Duration (minutes)
                </Label>
                <Input
                  id="duration"
                  type="number"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  className="bg-slate-800 border-slate-700 text-white"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-slate-300">How did you feel?</Label>
              <div className="grid grid-cols-5 gap-2">
                {feelingOptions.map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setFeeling(option.value)}
                    className={`p-3 rounded-xl border-2 transition-all ${
                      feeling === option.value
                        ? "border-orange-500 bg-orange-500/10"
                        : "border-slate-700 bg-slate-800 hover:border-slate-600"
                    }`}
                  >
                    <option.icon className={`w-6 h-6 mx-auto mb-1 ${option.color}`} />
                    <p className="text-xs text-slate-300">{option.label}</p>
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-white">Exercises</CardTitle>
            <Button
              onClick={addExercise}
              variant="outline"
              size="sm"
              className="border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Exercise
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {exercises.length === 0 ? (
              <div className="text-center py-12 text-slate-400">
                <p>No exercises added yet</p>
                <p className="text-sm mt-1">Click "Add Exercise" to start logging</p>
              </div>
            ) : (
              exercises.map((exercise, exIndex) => (
                <div key={exIndex} className="p-4 bg-slate-800/30 rounded-xl space-y-3">
                  <div className="flex gap-3">
                    <Input
                      value={exercise.exercise_name}
                      onChange={(e) => updateExercise(exIndex, "exercise_name", e.target.value)}
                      placeholder="Exercise name"
                      className="flex-1 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                    />
                    <Button
                      onClick={() => removeExercise(exIndex)}
                      variant="ghost"
                      size="icon"
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="space-y-2">
                    {exercise.sets_completed?.map((set, setIndex) => (
                      <div key={setIndex} className="grid grid-cols-[auto_1fr_1fr_auto] gap-2 items-center">
                        <span className="text-sm text-slate-400 w-12">Set {setIndex + 1}</span>
                        <Input
                          type="number"
                          value={set.reps}
                          onChange={(e) => updateSet(exIndex, setIndex, "reps", parseInt(e.target.value) || 0)}
                          placeholder="Reps"
                          className="bg-slate-800 border-slate-700 text-white text-sm"
                        />
                        <Input
                          type="number"
                          value={set.weight}
                          onChange={(e) => updateSet(exIndex, setIndex, "weight", parseFloat(e.target.value) || 0)}
                          placeholder="Weight (lbs)"
                          className="bg-slate-800 border-slate-700 text-white text-sm"
                        />
                        <button
                          type="button"
                          onClick={() => updateSet(exIndex, setIndex, "completed", !set.completed)}
                          className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
                            set.completed
                              ? "bg-gradient-to-br from-orange-500 to-orange-600"
                              : "bg-slate-700"
                          }`}
                        >
                          {set.completed && <span className="text-white text-xl">✓</span>}
                        </button>
                      </div>
                    ))}
                    <Button
                      onClick={() => addSet(exIndex)}
                      variant="outline"
                      size="sm"
                      className="w-full border-slate-700 text-slate-400 hover:bg-slate-800"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Set
                    </Button>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
          <CardContent className="pt-6">
            <Label htmlFor="notes" className="text-slate-300 mb-2 block">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="How did the workout go? Any observations?"
              rows={4}
              className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}