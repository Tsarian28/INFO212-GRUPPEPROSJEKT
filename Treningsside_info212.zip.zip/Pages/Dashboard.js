import React, { useState, useEffect } from "react";
import { WorkoutLog, Workout, Exercise } from "@/entities/all";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, startOfWeek, endOfWeek, eachDayOfInterval, isToday } from "date-fns";
import { Flame, Target, Calendar, TrendingUp, Plus, Dumbbell } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import StatsCard from "../components/dashboard/StatsCard";
import RecentWorkouts from "../components/dashboard/RecentWorkouts";
import WeeklyActivity from "../components/dashboard/WeeklyActivity";

export default function Dashboard() {
  const [logs, setLogs] = useState([]);
  const [workouts, setWorkouts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [fetchedLogs, fetchedWorkouts] = await Promise.all([
      WorkoutLog.list("-date", 30),
      Workout.list("-created_date", 10)
    ]);
    setLogs(fetchedLogs);
    setWorkouts(fetchedWorkouts);
    setLoading(false);
  };

  const thisWeekLogs = logs.filter(log => {
    const logDate = new Date(log.date);
    const weekStart = startOfWeek(new Date());
    const weekEnd = endOfWeek(new Date());
    return logDate >= weekStart && logDate <= weekEnd;
  });

  const totalWorkouts = logs.length;
  const thisWeekWorkouts = thisWeekLogs.length;
  const avgDuration = logs.length > 0
    ? Math.round(logs.reduce((sum, log) => sum + (log.duration_minutes || 0), 0) / logs.length)
    : 0;

  return (
    <div className="min-h-screen p-4 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Welcome Back!</h1>
            <p className="text-slate-400">Ready to crush your fitness goals today?</p>
          </div>
          <Link to={createPageUrl("LogWorkout")}>
            <Button className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white shadow-lg shadow-orange-500/30">
              <Plus className="w-5 h-5 mr-2" />
              Log Workout
            </Button>
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatsCard
            title="This Week"
            value={thisWeekWorkouts}
            subtitle="workouts completed"
            icon={Flame}
            gradient="from-orange-500 to-orange-600"
          />
          <StatsCard
            title="Total Workouts"
            value={totalWorkouts}
            subtitle="all time"
            icon={Target}
            gradient="from-blue-500 to-blue-600"
          />
          <StatsCard
            title="Avg Duration"
            value={`${avgDuration}m`}
            subtitle="per workout"
            icon={Calendar}
            gradient="from-purple-500 to-purple-600"
          />
          <StatsCard
            title="Active Days"
            value={new Set(logs.map(l => l.date)).size}
            subtitle="unique days"
            icon={TrendingUp}
            gradient="from-green-500 to-green-600"
          />
        </div>

        {/* Weekly Activity */}
        <WeeklyActivity logs={thisWeekLogs} />

        {/* Recent Workouts & Quick Actions */}
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <RecentWorkouts logs={logs.slice(0, 5)} loading={loading} />
          </div>

          <div className="space-y-6">
            <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white">Quick Start</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {workouts.slice(0, 3).map((workout) => (
                  <Link key={workout.id} to={createPageUrl("LogWorkout") + `?workout_id=${workout.id}`}>
                    <div className="p-4 bg-slate-800/50 rounded-xl hover:bg-slate-800 transition-all cursor-pointer group">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-orange-500/20 to-orange-600/20 rounded-lg flex items-center justify-center group-hover:from-orange-500/30 group-hover:to-orange-600/30 transition-all">
                          <Dumbbell className="w-5 h-5 text-orange-400" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-white">{workout.name}</p>
                          <p className="text-xs text-slate-400">
                            {workout.exercises?.length || 0} exercises
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
                {workouts.length === 0 && (
                  <div className="text-center py-6 text-slate-400">
                    <p className="mb-3">No workout templates yet</p>
                    <Link to={createPageUrl("MyWorkouts")}>
                      <Button variant="outline" size="sm" className="border-slate-700 text-slate-300">
                        Create Your First
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}