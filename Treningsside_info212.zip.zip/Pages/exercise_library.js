import React, { useState, useEffect } from "react";
import { Exercise } from "@/entities/all";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Dumbbell, Filter } from "lucide-react";
import ExerciseCard from "../components/exercises/ExerciseCard";

export default function ExerciseLibrary() {
  const [exercises, setExercises] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [muscleFilter, setMuscleFilter] = useState("all");
  const [equipmentFilter, setEquipmentFilter] = useState("all");

  useEffect(() => {
    loadExercises();
  }, []);

  const loadExercises = async () => {
    const data = await Exercise.list("-created_date");
    setExercises(data);
  };

  const filteredExercises = exercises.filter(exercise => {
    const matchesSearch = exercise.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesMuscle = muscleFilter === "all" || exercise.muscle_group === muscleFilter;
    const matchesEquipment = equipmentFilter === "all" || exercise.equipment === equipmentFilter;
    return matchesSearch && matchesMuscle && matchesEquipment;
  });

  return (
    <div className="min-h-screen p-4 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Exercise Library</h1>
          <p className="text-slate-400">Learn proper form and technique for each exercise</p>
        </div>

        <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search exercises..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
                />
              </div>

              <Select value={muscleFilter} onValueChange={setMuscleFilter}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="All Muscle Groups" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="all" className="text-white">All Muscle Groups</SelectItem>
                  <SelectItem value="chest" className="text-white">Chest</SelectItem>
                  <SelectItem value="back" className="text-white">Back</SelectItem>
                  <SelectItem value="legs" className="text-white">Legs</SelectItem>
                  <SelectItem value="shoulders" className="text-white">Shoulders</SelectItem>
                  <SelectItem value="arms" className="text-white">Arms</SelectItem>
                  <SelectItem value="core" className="text-white">Core</SelectItem>
                  <SelectItem value="full_body" className="text-white">Full Body</SelectItem>
                </SelectContent>
              </Select>

              <Select value={equipmentFilter} onValueChange={setEquipmentFilter}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="All Equipment" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="all" className="text-white">All Equipment</SelectItem>
                  <SelectItem value="barbell" className="text-white">Barbell</SelectItem>
                  <SelectItem value="dumbbell" className="text-white">Dumbbell</SelectItem>
                  <SelectItem value="machine" className="text-white">Machine</SelectItem>
                  <SelectItem value="bodyweight" className="text-white">Bodyweight</SelectItem>
                  <SelectItem value="cable" className="text-white">Cable</SelectItem>
                  <SelectItem value="kettlebell" className="text-white">Kettlebell</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {filteredExercises.length === 0 ? (
          <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <Dumbbell className="w-16 h-16 text-slate-700 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">No Exercises Found</h3>
              <p className="text-slate-400">Try adjusting your filters or add some exercises to the library</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredExercises.map((exercise) => (
              <ExerciseCard key={exercise.id} exercise={exercise} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}