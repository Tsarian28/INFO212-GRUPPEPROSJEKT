import React, { useState, useEffect } from "react";
import { WorkoutLog } from "@/entities/all";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { TrendingUp, Calendar, Dumbbell, Award } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, subMonths } from "date-fns";

export default function Progress() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    const data = await WorkoutLog.list("-date", 90);
    setLogs(data);
    setLoading(false);
  };

  const getWeeklyData = () => {
    const last12Weeks = [];
    for (let i = 11; i >= 0; i--) {
      const weekStart = new Date();
      weekStart.setDate(weekStart.getDate() - (i * 7));
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);

      const weekLogs = logs.filter(log => {
        const logDate = new Date(log.date);
        return logDate >= weekStart && logDate <= weekEnd;
      });

      last12Weeks.push({
        week: `Week ${12 - i}`,
        workouts: weekLogs.length,
        avgDuration: weekLogs.length > 0
          ? Math.round(weekLogs.reduce((sum, log) => sum + (log.duration_minutes || 0), 0) / weekLogs.length)
          : 0
      });
    }
    return last12Weeks;
  };

  const getVolumeData = () => {
    const last30Days = [];
    for (let i = 29; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = format(date, "yyyy-MM-dd");

      const dayLog = logs.find(log => log.date === dateStr);
      const totalVolume = dayLog?.exercises_completed?.reduce((sum, ex) => {
        return sum + (ex.sets_completed?.reduce((setSum, set) => {
          return setSum + (set.weight * set.reps);
        }, 0) || 0);
      }, 0) || 0;

      last30Days.push({
        date: format(date, "MMM dd"),
        volume: totalVolume
      });
    }
    return last30Days;
  };

  const getMuscleGroupData = () => {
    const muscleGroups = {};
    logs.forEach(log => {
      log.exercises_completed?.forEach(ex => {
        const name = ex.exercise_name.toLowerCase();
        let group = "Other";
        if (name.includes("bench") || name.includes("chest") || name.includes("push")) group = "Chest";
        else if (name.includes("squat") || name.includes("leg")) group = "Legs";
        else if (name.includes("row") || name.includes("pull") || name.includes("back")) group = "Back";
        else if (name.includes("shoulder") || name.includes("press")) group = "Shoulders";
        else if (name.includes("curl") || name.includes("tricep") || name.includes("arm")) group = "Arms";

        muscleGroups[group] = (muscleGroups[group] || 0) + 1;
      });
    });

    return Object.entries(muscleGroups).map(([name, count]) => ({ name, count }));
  };

  const weeklyData = getWeeklyData();
  const volumeData = getVolumeData();
  const muscleData = getMuscleGroupData();

  const totalWorkouts = logs.length;
  const totalVolume = logs.reduce((sum, log) => {
    return sum + (log.exercises_completed?.reduce((exSum, ex) => {
      return exSum + (ex.sets_completed?.reduce((setSum, set) => {
        return setSum + (set.weight * set.reps);
      }, 0) || 0);
    }, 0) || 0);
  }, 0);

  return (
    <div className="min-h-screen p-4 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Progress Tracking</h1>
          <p className="text-slate-400">Visualize your fitness journey and achievements</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center">
                  <Award className="w-6 h-6 text-white" />
                </div>
              </div>
              <p className="text-sm text-slate-400 mb-1">Total Workouts</p>
              <p className="text-3xl font-bold text-white">{totalWorkouts}</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
                  <Dumbbell className="w-6 h-6 text-white" />
                </div>
              </div>
              <p className="text-sm text-slate-400 mb-1">Total Volume</p>
              <p className="text-3xl font-bold text-white">{Math.round(totalVolume).toLocaleString()}</p>
              <p className="text-xs text-slate-500 mt-1">lbs lifted</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
              </div>
              <p className="text-sm text-slate-400 mb-1">Avg Per Week</p>
              <p className="text-3xl font-bold text-white">
                {(totalWorkouts / 12).toFixed(1)}
              </p>
              <p className="text-xs text-slate-500 mt-1">last 12 weeks</p>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
          <CardHeader>
            <CardTitle className="text-white">Weekly Workout Frequency</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="week" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1e293b",
                    border: "1px solid #334155",
                    borderRadius: "8px",
                    color: "#fff"
                  }}
                />
                <Bar dataKey="workouts" fill="url(#colorGradient)" radius={[8, 8, 0, 0]} />
                <defs>
                  <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#f97316" />
                    <stop offset="100%" stopColor="#ea580c" />
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-2 gap-6">
          <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
            <CardHeader>
              <CardTitle className="text-white">Training Volume (Last 30 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={volumeData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="date" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #334155",
                      borderRadius: "8px",
                      color: "#fff"
                    }}
                  />
                  <Line type="monotone" dataKey="volume" stroke="#3b82f6" strokeWidth={2} dot={{ fill: "#3b82f6" }} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
            <CardHeader>
              <CardTitle className="text-white">Muscle Group Focus</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={muscleData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis type="number" stroke="#94a3b8" />
                  <YAxis dataKey="name" type="category" stroke="#94a3b8" width={80} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #334155",
                      borderRadius: "8px",
                      color: "#fff"
                    }}
                  />
                  <Bar dataKey="count" fill="#a855f7" radius={[0, 8, 8, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}