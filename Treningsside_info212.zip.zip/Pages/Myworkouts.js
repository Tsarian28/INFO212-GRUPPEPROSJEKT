import React, { useState, useEffect } from "react";
import { Workout } from "@/entities/all";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import WorkoutList from "../components/workouts/WorkoutList";
import WorkoutForm from "../components/workouts/WorkoutForm";

export default function MyWorkouts() {
  const [workouts, setWorkouts] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingWorkout, setEditingWorkout] = useState(null);

  useEffect(() => {
    loadWorkouts();
  }, []);

  const loadWorkouts = async () => {
    const data = await Workout.list("-created_date");
    setWorkouts(data);
  };

  const handleSave = async (workoutData) => {
    if (editingWorkout) {
      await Workout.update(editingWorkout.id, workoutData);
    } else {
      await Workout.create(workoutData);
    }
    setShowForm(false);
    setEditingWorkout(null);
    loadWorkouts();
  };

  const handleEdit = (workout) => {
    setEditingWorkout(workout);
    setShowForm(true);
  };

  const handleDelete = async (workoutId) => {
    if (confirm("Are you sure you want to delete this workout?")) {
      await Workout.delete(workoutId);
      loadWorkouts();
    }
  };

  return (
    <div className="min-h-screen p-4 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">My Workouts</h1>
            <p className="text-slate-400">Create and manage your workout templates</p>
          </div>
          <Button
            onClick={() => {
              setEditingWorkout(null);
              setShowForm(true);
            }}
            className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
          >
            <Plus className="w-5 h-5 mr-2" />
            New Workout
          </Button>
        </div>

        {showForm ? (
          <WorkoutForm
            workout={editingWorkout}
            onSave={handleSave}
            onCancel={() => {
              setShowForm(false);
              setEditingWorkout(null);
            }}
          />
        ) : (
          <WorkoutList
            workouts={workouts}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        )}
      </div>
    </div>
  );
}