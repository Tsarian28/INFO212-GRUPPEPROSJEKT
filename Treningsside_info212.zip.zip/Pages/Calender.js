import React, { useState, useEffect } from "react";
import { WorkoutLog } from "@/entities/all";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Dumbbell, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  format,
  isSameMonth,
  isToday,
  addMonths,
  subMonths
} from "date-fns";

export default function Calendar() {
  const [logs, setLogs] = useState([]);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    const data = await WorkoutLog.list("-date");
    setLogs(data);
  };

  const getDaysInMonth = () => {
    const start = startOfMonth(currentMonth);
    const end = endOfMonth(currentMonth);
    return eachDayOfInterval({ start, end });
  };

  const getWorkoutsForDate = (date) => {
    const dateStr = format(date, "yyyy-MM-dd");
    return logs.filter(log => log.date === dateStr);
  };

  const days = getDaysInMonth();
  const firstDayOfWeek = days[0].getDay();
  const selectedWorkouts = selectedDate ? getWorkoutsForDate(selectedDate) : [];

  return (
    <div className="min-h-screen p-4 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Workout Calendar</h1>
          <p className="text-slate-400">Track your training consistency</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 bg-slate-900/50 border-slate-800 backdrop-blur-xl">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white flex items-center gap-2">
                  <CalendarIcon className="w-5 h-5 text-orange-400" />
                  {format(currentMonth, "MMMM yyyy")}
                </CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
                    className="border-slate-700 text-slate-300 hover:bg-slate-800"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
                    className="border-slate-700 text-slate-300 hover:bg-slate-800"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2 mb-4">
                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(day => (
                  <div key={day} className="text-center text-sm font-medium text-slate-400 pb-2">
                    {day}
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-2">
                {Array(firstDayOfWeek).fill(null).map((_, i) => (
                  <div key={`empty-${i}`} className="aspect-square" />
                ))}

                {days.map(day => {
                  const workouts = getWorkoutsForDate(day);
                  const hasWorkout = workouts.length > 0;
                  const today = isToday(day);
                  const isSelected = selectedDate && format(selectedDate, "yyyy-MM-dd") === format(day, "yyyy-MM-dd");

                  return (
                    <button
                      key={day.toISOString()}
                      onClick={() => setSelectedDate(day)}
                      className={`aspect-square rounded-xl p-2 transition-all relative ${
                        isSelected
                          ? "bg-orange-500 text-white"
                          : hasWorkout
                          ? "bg-slate-800 hover:bg-slate-700"
                          : today
                          ? "bg-slate-800/50 border-2 border-orange-500/50"
                          : "bg-slate-800/30 hover:bg-slate-800/50"
                      }`}
                    >
                      <div className="text-sm font-medium">{format(day, "d")}</div>
                      {hasWorkout && (
                        <div className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-1">
                          {workouts.slice(0, 3).map((_, i) => (
                            <div
                              key={i}
                              className={`w-1 h-1 rounded-full ${
                                isSelected ? "bg-white" : "bg-orange-500"
                              }`}
                            />
                          ))}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl">
            <CardHeader>
              <CardTitle className="text-white">
                {selectedDate ? format(selectedDate, "MMM dd, yyyy") : "Select a date"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedDate ? (
                selectedWorkouts.length > 0 ? (
                  selectedWorkouts.map((workout, index) => (
                    <div key={workout.id} className="p-4 bg-slate-800/30 rounded-xl space-y-2">
                      <div className="flex items-start justify-between">
                        <h3 className="font-semibold text-white">{workout.workout_name}</h3>
                        <Badge variant="outline" className="border-slate-700 text-slate-300">
                          {workout.feeling}
                        </Badge>
                      </div>

                      <div className="flex gap-4 text-sm text-slate-400">
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {workout.duration_minutes}m
                        </span>
                        <span className="flex items-center gap-1">
                          <Dumbbell className="w-4 h-4" />
                          {workout.exercises_completed?.length || 0} exercises
                        </span>
                      </div>

                      {workout.notes && (
                        <p className="text-sm text-slate-400 pt-2 border-t border-slate-700">
                          {workout.notes}
                        </p>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-slate-400">
                    <Dumbbell className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>No workouts on this day</p>
                  </div>
                )
              ) : (
                <div className="text-center py-8 text-slate-400">
                  <CalendarIcon className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>Click on a date to see workouts</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}