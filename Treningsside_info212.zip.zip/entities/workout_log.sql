{
  "name": "WorkoutLog",
  "type": "object",
  "properties": {
    "workout_id": {
      "type": "string",
      "description": "Reference to the workout template"
    },
    "workout_name": {
      "type": "string"
    },
    "date": {
      "type": "string",
      "format": "date"
    },
    "duration_minutes": {
      "type": "number"
    },
    "exercises_completed": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "exercise_id": {
            "type": "string"
          },
          "exercise_name": {
            "type": "string"
          },
          "sets_completed": {
            "type": "array",
            "items": {
              "type": "object",
              "properties": {
                "reps": {
                  "type": "number"
                },
                "weight": {
                  "type": "number"
                },
                "completed": {
                  "type": "boolean"
                }
              }
            }
          }
        }
      }
    },
    "notes": {
      "type": "string"
    },
    "feeling": {
      "type": "string",
      "enum": [
        "great",
        "good",
        "okay",
        "tired",
        "struggled"
      ],
      "description": "How you felt during the workout"
    }
  },
  "required": [
    "workout_name",
    "date"
  ]
}