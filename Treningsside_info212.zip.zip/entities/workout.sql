{
  "name": "Workout",
  "type": "object",
  "properties": {
    "name": {
      "type": "string",
      "description": "Name of the workout routine"
    },
    "description": {
      "type": "string",
      "description": "Description of the workout"
    },
    "exercises": {
      "type": "array",
      "description": "List of exercises in this workout",
      "items": {
        "type": "object",
        "properties": {
          "exercise_id": {
            "type": "string"
          },
          "exercise_name": {
            "type": "string"
          },
          "sets": {
            "type": "number"
          },
          "reps": {
            "type": "number"
          },
          "rest_seconds": {
            "type": "number"
          },
          "notes": {
            "type": "string"
          }
        }
      }
    },
    "estimated_duration": {
      "type": "number",
      "description": "Estimated duration in minutes"
    },
    "is_template": {
      "type": "boolean",
      "default": true
    }
  },
  "required": [
    "name"
  ]
}