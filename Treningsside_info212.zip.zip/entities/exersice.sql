{
  "name": "Exercise",
  "type": "object",
  "properties": {
    "name": {
      "type": "string",
      "description": "Name of the exercise"
    },
    "muscle_group": {
      "type": "string",
      "enum": [
        "chest",
        "back",
        "legs",
        "shoulders",
        "arms",
        "core",
        "full_body"
      ],
      "description": "Primary muscle group targeted"
    },
    "equipment": {
      "type": "string",
      "enum": [
        "barbell",
        "dumbbell",
        "machine",
        "bodyweight",
        "cable",
        "kettlebell",
        "resistance_band"
      ],
      "description": "Equipment needed"
    },
    "difficulty": {
      "type": "string",
      "enum": [
        "beginner",
        "intermediate",
        "advanced"
      ],
      "description": "Difficulty level"
    },
    "instructions": {
      "type": "string",
      "description": "Step-by-step instructions"
    },
    "tips": {
      "type": "string",
      "description": "Form tips and safety notes"
    },
    "video_url": {
      "type": "string",
      "description": "Optional video demonstration URL"
    }
  },
  "required": [
    "name",
    "muscle_group",
    "equipment"
  ]
}